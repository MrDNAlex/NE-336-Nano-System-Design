# -*- coding: utf-8 -*-
"""
Created on Tue Oct 29 17:31:24 2024

@author: a3dufres
"""








